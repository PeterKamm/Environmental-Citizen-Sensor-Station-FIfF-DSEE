/*
 * dcf77.h
 *
 *  Created on: May 7, 2023
 *      Author: peterka
 */

#ifndef DCF77_H_
#define DCF77_H_

#include "main.h"
//#include "FreeRTOS.h"
//#include "stream_buffer.h"

struct dcf77_struct
{
//	0		Startbit
//	1..14	Wetterinformation
//	15		Rufbit
//	16		1 Ankündigung Umstellung MEZ / MESZ
//	17..18	Zeitsystem 01: MEZ / 10: MESZ
//	19		1: Ankündigung Einfügen Schaltsekunde
//	20		Beginn Zeitinfo
//	21..24	Minute Einer
//	25..27	Minute Zehner
//	28		Parität Minute
//	29..32	Stunde Einer
//	33..34	Stunde Zehner
//	35		Parität Stunde
//	36..39	Kalendertag Einer
//	40..41	Kalendertag Zehner
//	42..44	Monat Einer
//	45..48	Monat Zehner
//	49		Monat Zehner
//	50..53	Jahr Einer
//	54..57	Jahr Zehner
//	58		Parität Datum
//	59		fehlt, Minutenmarke

	uint64_t	last_bits;
	uint8_t		last_bits_valid;
	uint8_t		time_valid;
	uint8_t		timesystem;	// MEZ MESZ
	uint8_t		day_of_week;
	uint8_t		minute;
	uint8_t		hour;
	uint8_t		month;
	uint8_t		year;
};

void dcf77_init(void);
void dcf77_stat(void);
void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin);
void HAL_GPIO_EXTI_Falling_Callback(uint16_t GPIO_Pin);

#endif /* DCF77_H_ */
