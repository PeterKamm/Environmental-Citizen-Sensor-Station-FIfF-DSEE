/*!
  * @file      LFSDF.c
  *
  * @brief     Implements the Cayenne Low Power Protocol
  *
*/

#include "stm32_mem.h"
#include "LFSDF.h"
#include "stdio.h"

#define LFSDF_MAXBUFFER_SIZE	242
#define LFSDF_DIGITAL_INPUT       0       /* 1 byte */
#define LFSDF_DIGITAL_OUTPUT      1       /* 1 byte */
#define LFSDF_ANALOG_INPUT        2       /* 2 bytes, 0.01 signed */
#define LFSDF_ANALOG_OUTPUT       3       /* 2 bytes, 0.01 signed */
#define LFSDF_LUMINOSITY          101     /* 2 bytes, 1 lux unsigned */
#define LFSDF_PRESENCE            102     /* 1 byte, 1 */
#define LFSDF_TEMPERATURE         12     /* 2 bytes, 0.1 Celsius degrees signed */
#define LFSDF_RELATIVE_HUMIDITY   104     /* 1 byte, 0.5% unsigned */
#define LFSDF_ACCELEROMETER       113     /* 2 bytes per axis, 0.001G */
#define LFSDF_BAROMETRIC_PRESSURE 115     /* 2 bytes 0.1 hPa Unsigned */
#define LFSDF_GYROMETER           	134     /* 2 bytes per axis, 0.01 degrees/s */
#define LFSDF_GPS                 	136     /* 3 byte lon/lat 0.0001 degrees, 3 bytes alt 0.01m */
#define LFSDF_CPM					22     /* 1 Byte Channel; 2 Byte Count per Minute	*/
#define LFSDF_Timestamp				1

/* Data ID + Data Type + Data Size */
#define LFSDF_DIGITAL_INPUT_SIZE       	3
#define LFSDF_DIGITAL_OUTPUT_SIZE      	3
#define LFSDF_ANALOG_INPUT_SIZE       	4
#define LFSDF_ANALOG_OUTPUT_SIZE      	4
#define LFSDF_LUMINOSITY_SIZE          	4
#define LFSDF_PRESENCE_SIZE           	3
#define LFSDF_TEMPERATURE_SIZE         	4
#define LFSDF_RELATIVE_HUMIDITY_SIZE   	3
#define LFSDF_ACCELEROMETER_SIZE      	8
#define LFSDF_BAROMETRIC_PRESSURE_SIZE 	4
#define LFSDF_GYROMETER_SIZE          	8
#define LFSDF_GPS_SIZE					11
#define LFSDF_CPM_SIZE				 	4
#define LFSDF_Timestamp_SIZE			4
#define LFSDF_PAGE_SIZE					1

static uint8_t LFSDFBuffer[LFSDF_MAXBUFFER_SIZE];
static uint8_t LFSDFCursor = 0;

void LFSDFInit(void)
{
  LFSDFCursor = 0;
}


void LFSDFReset(LFSDFResetEnum cmd)
{
	uint32_t i;
	LFSDFCursor = 0;
	switch (cmd)
	{
	case simple:
		;
		break;
	case null:
		for(i=0; i<LFSDF_MAXBUFFER_SIZE; i++){
			LFSDFBuffer[i] = 0;
		};
		break;
	case test:
		for(i=0; i<LFSDF_MAXBUFFER_SIZE; i++){
			LFSDFBuffer[i] = i;
		};
		break;
	default:
		;
	}
}


uint8_t LFSDFGetSize(void)
{
  return LFSDFCursor;
}


uint8_t *LFSDFGetBuffer(void)
{
  return LFSDFBuffer;
}


void LFSDFWriteByte(uint8_t byte)
{
	if ((LFSDFCursor + 1) > LFSDF_MAXBUFFER_SIZE)
	{
		return;
	}
	LFSDFBuffer[LFSDFCursor++] = byte;
  //return LFSDFBuffer;
}


void LFSDFWriteBytes(uint8_t *bytes, uint16_t size)
{
	if ((LFSDFCursor + size) > LFSDF_MAXBUFFER_SIZE)
	{
		return;
	}
	UTIL_MEM_cpy_8(LFSDFBuffer, bytes, size);
	LFSDFCursor += size;
}


void LFSDFWriteString(char *string)
{
	uint16_t stringlen,i;
	stringlen = strlen(string);
	if ((LFSDFCursor + stringlen) > LFSDF_MAXBUFFER_SIZE)
	{
		return;
	}
	for(i=0; i<stringlen; i++)
	{
		LFSDFBuffer[LFSDFCursor++] = (uint8_t)string[i];
	}
}


void LFSDFTestOverwrite(void)
{
	uint16_t i;
	for(i=0; i<LFSDFCursor; i++)
	{
		LFSDFBuffer[i] = (char)(i+33);
	}
}


uint8_t LFSDFCopy(uint8_t *dst)
{
  UTIL_MEM_cpy_8(dst, LFSDFBuffer, LFSDFCursor);
  return LFSDFCursor;
}

uint8_t LFSDFWritePage(uint8_t page, char *str)
{
	if ((LFSDFCursor + LFSDF_PAGE_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
		return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x", page);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = page;
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddTimestamp(int32_t time, char *str)
{
	if ((LFSDFCursor + LFSDF_DIGITAL_OUTPUT_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
		return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x%02x", LFSDF_Timestamp, (uint8_t)(time >> 24), (uint8_t)(time >> 16), (uint8_t)(time >> 8), (uint8_t)(time));
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = LFSDF_Timestamp;
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(time >> 24);
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(time >> 16);
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(time >> 8);
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(time);
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddCPM(uint8_t channel, uint32_t cpm, char *str)
{
	if ((LFSDFCursor + LFSDF_CPM_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
		return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x%02x", LFSDF_CPM, channel, (uint8_t)(cpm >> 16), (uint8_t)(cpm >> 8), (uint8_t)(cpm));
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = LFSDF_CPM;
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(cpm >> 16);
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(cpm >> 8);
	LFSDFBuffer[LFSDFCursor++] = (uint8_t)(cpm);
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddDigitalInput(uint8_t channel, uint8_t value, char *str)
{
	if ((LFSDFCursor + LFSDF_DIGITAL_INPUT_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
		return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x", channel, LFSDF_DIGITAL_INPUT, value);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_DIGITAL_INPUT;
	LFSDFBuffer[LFSDFCursor++] = value;
#endif
	return LFSDFCursor;
}


uint8_t LFSDFAddDigitalOutput(uint8_t channel, uint8_t value, char *str)
{
	if ((LFSDFCursor + LFSDF_DIGITAL_OUTPUT_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
		return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x", channel, LFSDF_DIGITAL_OUTPUT, value);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_DIGITAL_OUTPUT;
	LFSDFBuffer[LFSDFCursor++] = value;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddAnalogInput(uint8_t channel, float value, char *str)
{
	if ((LFSDFCursor + LFSDF_ANALOG_INPUT_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int16_t val = (int16_t)(value * 100);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x", channel, LFSDF_ANALOG_INPUT, (uint8_t)(val >> 8), (uint8_t)(val));
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = LFSDF_ANALOG_INPUT;
  LFSDFBuffer[LFSDFCursor++] = val >> 8;
  LFSDFBuffer[LFSDFCursor++] = val;
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddAnalogOutput(uint8_t channel, float value, char *str)
{
  if ((LFSDFCursor + LFSDF_ANALOG_OUTPUT_SIZE) > LFSDF_MAXBUFFER_SIZE)
  {
    return 0;
  }
  int16_t val = (int16_t)(value * 100);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x", channel, LFSDF_ANALOG_OUTPUT, (uint8_t)(val >> 8), (uint8_t)val);
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = LFSDF_ANALOG_OUTPUT;
  LFSDFBuffer[LFSDFCursor++] = val >> 8;
  LFSDFBuffer[LFSDFCursor++] = val;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddLuminosity(uint8_t channel, uint16_t lux, char *str)
{
	if ((LFSDFCursor + LFSDF_LUMINOSITY_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x", channel, LFSDF_LUMINOSITY, (uint8_t)(lux >> 8), (uint8_t)lux);
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = LFSDF_LUMINOSITY;
  LFSDFBuffer[LFSDFCursor++] = lux >> 8;
  LFSDFBuffer[LFSDFCursor++] = lux;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddPresence(uint8_t channel, uint8_t value, char *str)
{
	if ((LFSDFCursor + LFSDF_PRESENCE_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x", channel, LFSDF_PRESENCE, value);
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = LFSDF_PRESENCE;
  LFSDFBuffer[LFSDFCursor++] = value;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddTemperature(uint8_t channel, float celsius, char *str)
{
	if ((LFSDFCursor + LFSDF_TEMPERATURE_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int16_t val = (int16_t)(celsius + 273.15);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x", LFSDF_TEMPERATURE, channel, (uint8_t)(val >> 8), (uint8_t)val);
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = LFSDF_TEMPERATURE;
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = val >> 8;
  LFSDFBuffer[LFSDFCursor++] = val;
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddRelativeHumidity(uint8_t channel, float rh, char *str)
{
	if ((LFSDFCursor + LFSDF_RELATIVE_HUMIDITY_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x", channel, LFSDF_RELATIVE_HUMIDITY, (uint8_t)(rh * 2));
	LFSDFWriteString(str);
#else
  LFSDFBuffer[LFSDFCursor++] = channel;
  LFSDFBuffer[LFSDFCursor++] = LFSDF_RELATIVE_HUMIDITY;
  LFSDFBuffer[LFSDFCursor++] = (uint8_t)(rh * 2);
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddAccelerometer(uint8_t channel, float x, float y, float z, char *str)
{
	if ((LFSDFCursor + LFSDF_ACCELEROMETER_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int16_t vx = (int16_t)(x * 1000);
	int16_t vy = (int16_t)(y * 1000);
	int16_t vz = (int16_t)(z * 1000);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x%02x%02x%02x%02x", channel, LFSDF_ACCELEROMETER, (uint8_t)(vx >> 8), (uint8_t)vx, (uint8_t)(vy >> 8), (uint8_t)vy, (uint8_t)(vz >> 8), (uint8_t)vz);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_ACCELEROMETER;
	LFSDFBuffer[LFSDFCursor++] = vx >> 8;
	LFSDFBuffer[LFSDFCursor++] = vx;
	LFSDFBuffer[LFSDFCursor++] = vy >> 8;
	LFSDFBuffer[LFSDFCursor++] = vy;
	LFSDFBuffer[LFSDFCursor++] = vz >> 8;
	LFSDFBuffer[LFSDFCursor++] = vz;
#endif
  return LFSDFCursor;
}


uint8_t LFSDFAddBarometricPressure(uint8_t channel, float hpa, char *str)
{
	if ((LFSDFCursor + LFSDF_BAROMETRIC_PRESSURE_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int16_t val = (int16_t)(hpa * 10);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x", channel, LFSDF_BAROMETRIC_PRESSURE, (uint8_t)(val >> 8), (uint8_t)val);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_BAROMETRIC_PRESSURE;
	LFSDFBuffer[LFSDFCursor++] = val >> 8;
	LFSDFBuffer[LFSDFCursor++] = val;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddGyrometer(uint8_t channel, float x, float y, float z, char *str)
{
	if ((LFSDFCursor + LFSDF_GYROMETER_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int16_t vx = (int16_t)(x * 100);
	int16_t vy = (int16_t)(y * 100);
	int16_t vz = (int16_t)(z * 100);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x%02x%02x%02x%02x", channel,  LFSDF_GYROMETER, (uint8_t)(vx >> 8), (uint8_t)vx, (uint8_t)(vy >> 8), (uint8_t)vy, (uint8_t)(vz >> 8), (uint8_t)vz);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_GYROMETER;
	LFSDFBuffer[LFSDFCursor++] = vx >> 8;
	LFSDFBuffer[LFSDFCursor++] = vx;
	LFSDFBuffer[LFSDFCursor++] = vy >> 8;
	LFSDFBuffer[LFSDFCursor++] = vy;
	LFSDFBuffer[LFSDFCursor++] = vz >> 8;
	LFSDFBuffer[LFSDFCursor++] = vz;
#endif
  return LFSDFCursor;
}

uint8_t LFSDFAddGps(uint8_t channel, float latitude, float longitude, float meters, char *str)
{
	if ((LFSDFCursor + LFSDF_GPS_SIZE) > LFSDF_MAXBUFFER_SIZE)
	{
	return 0;
	}
	int32_t lat = (int32_t)(latitude * 10000);
	int32_t lon = (int32_t)(longitude * 10000);
	int32_t alt = (int32_t)(meters * 100);
#ifdef LFSDFtoString
	sprintf(str, "%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x", channel, LFSDF_BAROMETRIC_PRESSURE, (uint8_t)(lat >> 16), (uint8_t)(lat >> 8), (uint8_t)lat, (uint8_t)(lon >> 16), (uint8_t)(lon >> 8), (uint8_t)lon, (uint8_t)(alt >> 16), (uint8_t)(alt >> 8), (uint8_t)alt);
	LFSDFWriteString(str);
#else
	LFSDFBuffer[LFSDFCursor++] = channel;
	LFSDFBuffer[LFSDFCursor++] = LFSDF_GPS;
	LFSDFBuffer[LFSDFCursor++] = lat >> 16;
	LFSDFBuffer[LFSDFCursor++] = lat >> 8;
	LFSDFBuffer[LFSDFCursor++] = lat;
	LFSDFBuffer[LFSDFCursor++] = lon >> 16;
	LFSDFBuffer[LFSDFCursor++] = lon >> 8;
	LFSDFBuffer[LFSDFCursor++] = lon;
	LFSDFBuffer[LFSDFCursor++] = alt >> 16;
	LFSDFBuffer[LFSDFCursor++] = alt >> 8;
	LFSDFBuffer[LFSDFCursor++] = alt;
#endif
  return LFSDFCursor;
}


//uint8_t LFSDFAdduSievert(uint8_t channel, uint32_t uSv)
//{
//	char str[250];
//	if ((LFSDFCursor + LFSDF_uSievert_SIZE) > LFSDF_MAXBUFFER_SIZE)
//	{
//	return 0;
//	}
//#ifdef LFSDFtoString
//	sprintf(str, "%02x%02x%02x%02x%02x%02x", channel, LFSDF_USIEVERT, (uint8_t)(uSv >> 24), (uint8_t)(uSv >> 16), (uint8_t)(uSv >> 8), (uint8_t)uSv);
//	LFSDFWriteString(str);
//#else
//	Cayenn	char str[250];
//	ppBuffer[LFSDFCursor++] = uSv;
//#endif
//  return LFSDFCursor;
//}


/* USER CODE END EF */

/* Private Functions Definition -----------------------------------------------*/
/* USER CODE BEGIN PrFD */

/* USER CODE END PrFD */
