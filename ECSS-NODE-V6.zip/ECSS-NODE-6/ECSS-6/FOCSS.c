/*
 * FOCSS.c
 *
 *  Created on: Aug 26, 2022
 *      Author: peterka
 */

#include "ecss_periph.h"
#include "FOCSS.h"
#include "string.h"
#include "LFSDF.h"
#include "time.h"
#include "math.h"
#include "stdlib.h"
//#include "gpt.h"

//char DevEui_mem[] = DevEui_default_def;
//char AppEui_mem[] = AppEui_default_def;
//char DevAddr_mem[] = DevAddr_default_def;
//char APPKEY_mem[] = APPKEY_default_def;
//
//struct lrw_reg_s {
//	char *DevEui;
//	char *AppEui;
//	char *DxxEui;
//	char *APPKEY;
//} lrw_reg = {
//	DevEui_mem,
//	AppEui_mem,
//	DevAddr_mem,
//	APPKEY_mem
//};


#define ecss_node_2

// tdrm node 1 Board Rev. 0.0.1 STM32G071CBU3
#ifdef ecss_node_1
#define Node_Name			("node-1")
#define DevEui_default_def	("2C:F7:F1:20:42:00:41:D1")
#define AppEui_default_def	("80:00:00:00:00:00:00:06")
#define DevAddr_default_def	("42:00:41:D1")
#define APPKEY_default_def	("2E7E151628AED2A6ABF7158809CF4F3C")
#define Scheme_default_def	("EU868")
#define FOCSS_DeviceToken	("12345678")
#endif


// tdrm node 2 Board Rev. 0.0.1 STM32G071CBU3
#ifdef ecss_node_2
#define Node_Name			("node-2")
#define DevEui_default_def	("2C:F7:F1:20:42:00:41:D2")
#define AppEui_default_def	("2C:F7:F1:20:42:00:41:D2")
//("80:00:00:00:00:00:00:07")
#define DevAddr_default_def	("26:0B:55:28")
#define APPKEY_default_def	("2E7E151628AED2A6ABF7158809CF4F3E")
#define Scheme_default_def	("EU868")
#define FOCSS_DeviceToken	("12345679")
#endif



// tdrm node 1_alt with TDRM-Board Rev. 0.0.1 STM32G071CBU3
#ifdef ecss_node_1_alt
#define Node_Name			("tdrm_node_1")
#define DevEui_default_def	("2C:F7:F1:20:32:30:C6:69")
#define AppEui_default_def	("80:00:00:00:00:00:00:06")
#define DevAddr_default_def	("32:30:C6:69")
#define APPKEY_default_def	("2B7E151628AED2A6ABF7158809CF4F3C")
#define Scheme_default_def	("EU868")
#define FOCSS_DeviceToken	("12345678")
#endif

// tdrm node 2_alt with eval-board Nucleo-32 STM32L432KC
#ifdef esn_node_2_alt
#define Node_Name			("tdrm_node_2")
#define DevEui_default_def	("2C:F7:F1:20:32:30:C6:69")
#define AppEui_default_def	("80:00:00:00:00:00:00:06")
#define DevAddr_default_def	("32:30:C6:69")
#define APPKEY_default_def	("2C7E151628AED2A6ABF7158809CF4F3C")
#define Scheme_default_def	("EU868")
#define FOCSS_DeviceToken	("12345679")
#endif

// tdrm node 3_alt with eval-board Nucleo-32 STM32L432KC
#ifdef esn_node_3_alt
#define Node_Name			("tdrm_node_3")
#define DevEui_default_def	("2C:F7:F1:20:32:30:C6:3F")
#define AppEui_default_def	("80:00:00:00:00:00:00:06")
#define DevAddr_default_def	("32:30:C6:3F")
#define APPKEY_default_def	("2D7E151628AED2A6ABF7158809CF4F3C")
#define Scheme_default_def	("EU868")
#define FOCSS_DeviceToken	("12345680")
#endif

static char *DevEui_default = (DevEui_default_def);
static char *AppEui_default = (AppEui_default_def);
static char *DevAddr_default = (DevAddr_default_def);
static char *APPKEY_default = (APPKEY_default_def);
//static char *Scheme_default = (Scheme_default_def);

#define DevEui_len (24)
#define AppEui_len (24)
#define DevAddr_len (12)
#define APPKEY_len (33)
#define Scheme_len (30)
// FIX

char DevEui_mem[DevEui_len];
char AppEui_mem[AppEui_len];
char DevAddr_mem[DevAddr_len];
char APPKEY_mem[APPKEY_len];
char Scheme_mem[APPKEY_len];

char *DevEui_p = DevEui_mem;
char *AppEui_p = AppEui_mem;
char *DevAddr_p = DevAddr_mem;
char *APPKEY_p = APPKEY_mem;
char *Scheme_p = Scheme_mem;

uint8_t buf_t_mem[lrw_buf_r_len];
uint8_t *buf_t = buf_t_mem;

uint8_t buf_r_mem[lrw_buf_r_len];
uint8_t *buf_r = buf_r_mem;

int32_t unix_timestamp = 1686004100;

char str[50];

void FOCSS_init(void){
//	char *substr;
	LFSDFInit();
	FOCSS_lrw_cmd(FOCSS_get);
//	FOCSS_lrw_cmd(FOCSS_set_key);
	FOCSS_lrw_cmd(FOCSS_join);
//	yyyy
//	substr = strstr((const char *)buf_r, "+JOIN: Network joined");
//	substr = strstr((const char *)buf_r, "+JOIN: Done");
//	FOCSS_user_transmit(buf_r);
}

void FOCSS_init_buf(uint8_t *buf, uint16_t len){
	uint16_t i;
	for(i=0; i<len; i++){
		buf[i] = 0;
	}
}

FOCSS_ent FOCSS_user_transmit(uint8_t *string)
{
	HAL_StatusTypeDef status = HAL_BUSY;

	status = HAL_UART_Transmit(&huart_user, (const uint8_t *) string, strlen((char*)string), 100);
//	do {
//		status = HAL_UART_Transmit_DMA(&huart_user, (const uint8_t *)string, (uint16_t)strlen((char *)string));
//		HAL_StatusTypeDef HAL_UART_Transmit_DMA(UART_HandleTypeDef *huart, const uint8_t *pData, uint16_t Size);
//	} while (status == HAL_BUSY);

	return 0;  //(FOCSS_ent) status;
}


FOCSS_ent FOCSS_lrw_tr(uint8_t *buf_t, uint16_t size_t, uint8_t *buf_r, uint16_t size_r)
{
	HAL_StatusTypeDef status;
	//uint16_t len;
	status = HAL_UART_Transmit(&huart_lrw, buf_t, size_t, 100);
	status = HAL_UART_Receive(&huart_lrw, buf_r, size_r, 200);
	//len = strlen((char *)buf_r);

	return (FOCSS_ent) status;
}


FOCSS_ent FOCSS_lrw_cmd(FOCSS_ent cmd)
{
	FOCSS_ent status;
	uint16_t i;

	switch (cmd)
	{

	case FOCSS_get :		// DevEui AppEui DevAddr
		status = FOCSS_lrw_tr((uint8_t *)"\r\nAT+ID=DevEui\r\n", 16, buf_r, 50);
		for(i=0; i < (DevEui_len-1); i++){
			DevEui_mem[i] = buf_r_mem[i+13];
		};
		DevEui_mem[i] = '\0';

		status = FOCSS_lrw_tr((uint8_t *)"AT+ID=AppEui\r\n", 14, buf_r, 50);
		for(i=0; i < (AppEui_len-1); i++){
			AppEui_mem[i] = buf_r_mem[i+13];
		};
		AppEui_mem[i] = '\0';

		status = FOCSS_lrw_tr((uint8_t *)"AT+ID=DevAddr\r\n", 15, buf_r, 50);
		for(i=0; i < (DevAddr_len-1); i++){
			DevAddr_mem[i] = buf_r_mem[i+14];
		};
		DevAddr_mem[i] = '\0';

		status = FOCSS_lrw_tr((uint8_t *)"AT+DR=SCHEME\r\n", 14, buf_r, 50);
		for(i=0; i < (Scheme_len-1); i++){
			Scheme_mem[i] = buf_r_mem[i+13];  //FIX
		};
		Scheme_mem[i] = '\0';
	break;

	case FOCSS_user :	// send DevEui, AppEui DevAddr to user UART

		status = FOCSS_user_transmit((uint8_t *)"\r\n");
		status = FOCSS_user_transmit((uint8_t *)Node_Name);
		status = FOCSS_user_transmit((uint8_t *)"\r\nDevEui: ");
		status = FOCSS_user_transmit((uint8_t *)DevEui_mem);
		status = FOCSS_user_transmit((uint8_t *)"\r\nAppEui: ");
		status = FOCSS_user_transmit((uint8_t *)AppEui_mem);
		status = FOCSS_user_transmit((uint8_t *)"\r\nDevAddr: ");
		status = FOCSS_user_transmit((uint8_t *)DevAddr_mem);
		status = FOCSS_user_transmit((uint8_t *)"\r\nScheme: ");
		status = FOCSS_user_transmit((uint8_t *)Scheme_mem);
		status = FOCSS_user_transmit((uint8_t *)"\r\n");
	break;

	case FOCSS_set :	// set DevEui AppEui DevAddr to LoRaWAN-Module

		strcpy((char *)buf_t, "\r\nAT+ID=DevEui, \"");
		for(i=0; i < (DevEui_len-1); i++){
			buf_t_mem[i+17] = DevEui_default[i];
		};
		buf_t_mem[i+17] = '\0';
		strcat((char *)buf_t,"\"\r\n");
		status = FOCSS_lrw_tr(buf_t, 43, buf_r, lrw_buf_r_len);

		strcpy((char *)buf_t, "AT+ID=AppEui, \"");
		for(i=0; i < (AppEui_len-1); i++){
			buf_t_mem[i+15] = AppEui_default[i];
		};
		buf_t_mem[i+15] = '\0';
		strcat((char *)buf_t,"\"\r\n");
		status = FOCSS_lrw_tr(buf_t, 41, buf_r, lrw_buf_r_len);

		strcpy((char *)buf_t, "AT+ID=DevAddr, \"");
		for(i=0; i < (DevAddr_len-1); i++){
			buf_t_mem[i+16] = DevAddr_default[i];
		};
		buf_t_mem[i+16] = '\0';
		strcat((char *)buf_t,"\"\r\n");
		status = FOCSS_lrw_tr(buf_t, 30, buf_r, lrw_buf_r_len);

		strcpy((char *)buf_t, "AT+DR=SCHEME, \""); // FIX
		for(i=0; i < (Scheme_len-1); i++){
			buf_t_mem[i+16] = DevAddr_default[i];
		};
		buf_t_mem[i+16] = '\0';
		strcat((char *)buf_t,"\"\r\n");
		status = FOCSS_lrw_tr(buf_t, 30, buf_r, lrw_buf_r_len);
	break;

	case FOCSS_join :
		FOCSS_init_buf(buf_r, lrw_buf_r_len);
		status = FOCSS_lrw_tr((uint8_t *)"AT+MODE=LWOTAA\r\n", 16, buf_r, lrw_buf_r_len);
		FOCSS_init_buf(buf_r, lrw_buf_r_len);
		status = FOCSS_lrw_tr((uint8_t *)"AT+JOIN\r\n", 9, buf_r, lrw_buf_r_len);
		//FOCSS_user_transmit((char *)buf_r);
	break;

	case FOCSS_set_key :
		strcpy((char *)buf_t, "AT+KEY=APPKEY, \"");
		for(i=0; i < (APPKEY_len-1); i++){
			buf_t_mem[i+16] = APPKEY_default[i];
		};
		buf_t_mem[i+16] = '\0';
		strcat((char *)buf_t,"\"\r\n");
		memset(buf_r,0,lrw_buf_r_len);
		status = FOCSS_lrw_tr(buf_t, 51, buf_r, lrw_buf_r_len);
	break;

	case FOCSS_compare :
		;
	break;
	default :
		;
	}
	return FOCSS_OK;
}


FOCSS_ent FOCSS_lrw_send_test(void){

	uint8_t buf[lrw_buf_r_len];
	uint8_t *buf_p = buf;
	FOCSS_ent status;

	LFSDFReset(test);
	LFSDFWriteString("AT+MSGHEX=\"");
	LFSDFAddDigitalInput(4,1,str);
	LFSDFWriteString(" ");
	LFSDFAddAnalogOutput(5, 4567.34, str);
	LFSDFWriteString(" ");
	//LFSDFAdduSievert(6, 789);
	LFSDFWriteString("\"\r\n");
	LFSDFWriteByte(0);
	status = FOCSS_lrw_tr(LFSDFGetBuffer(), LFSDFGetSize(), buf_p, lrw_buf_r_len);
	return status;		// FOCSS_OK;
}


FOCSS_ent FOCSS_lrw_send_test2(void){

	uint8_t buf[lrw_buf_r_len];
	uint8_t *buf_p = buf;
	FOCSS_ent status;

	LFSDFReset(test);
	LFSDFWriteString("AT+MSG=\"abcd\"\r\n");
	LFSDFWriteByte(0);
	status = FOCSS_lrw_tr(LFSDFGetBuffer(), LFSDFGetSize(), buf_p, lrw_buf_r_len);
	return status;		// FOCSS_OK;
}



FOCSS_ent FOCSS_lrw_send_test3(void){

	uint8_t buf[lrw_buf_r_len];
	uint8_t *buf_p = buf;
	FOCSS_ent status;
	uint32_t cpm=0;

	LFSDFReset(test);
	LFSDFWriteString("AT+MSG=\"");
//	LFSDFAddToken(FOCSS_DeviceToken);
//	LFSDFWriteString(" ");
	LFSDFAddTimestamp(unix_timestamp,str);
	//LFSDFWriteString(" ");
	LFSDFAddCPM(0, cpm++, str);
	//LFSDFWriteString(" ");
	LFSDFAddTemperature(0, 23.4, str);
	LFSDFWriteString("\"\r\n");
	LFSDFWriteByte(0);
	status = FOCSS_lrw_tr(LFSDFGetBuffer(), LFSDFGetSize(), buf_p, lrw_buf_r_len);
	return status;		// FOCSS_OK;
}


// send data of ecss_periph
FOCSS_ent FOCSS_lrw_send(void){

	uint8_t buf[lrw_buf_r_len];
	uint8_t *buf_p = buf;
	FOCSS_ent status;
	float temperature;
	uint32_t cpm;

	//ecss_periph_read();
	LFSDFReset(test);
	LFSDFWriteString("AT+MSG=\"");
//	LFSDFAddToken(FOCSS_DeviceToken);
//	LFSDFWriteString(" ");
	LFSDFWritePage(0, str);		// Page
	LFSDFAddTimestamp(unix_timestamp, str);
	unix_timestamp = unix_timestamp+60;		// plus 60 seconds
//	LFSDFWriteString(" ");
//	cpm = (uint8_t)(rand() % 12);
	cpm = ecss_periph_read_cpm();
	LFSDFAddCPM(0, cpm, str);
	//LFSDFWriteString(" ");***
	temperature = ((float)(rand() % 1000)/10)-20;
//	temperature = ((float)ecss_periph_read_temperature())/10;		// TEST
//	LFSDFAddTemperature(0, temperature, str);
	LFSDFAddTemperature(0, 11.1, str);
	LFSDFWriteString("\"\r\n");
	LFSDFWriteByte(0);
	status = FOCSS_lrw_tr(LFSDFGetBuffer(), LFSDFGetSize(), buf_p, lrw_buf_r_len);
	return status;		// FOCSS_OK;
}


