/*
 * ctrl-tim17.c
 *
 *  Created on: Mar 18, 2023
 *      Author: peterka
 */

#include "ecss-tim.h"
#include "stm32g0xx_hal.h"
#include "FOCSS.h"
#include "main.h"

//uint8_t htim_cycle_flag=0;

//void tim17_init(void){
//	/**
//	  * @brief  Starts the TIM Base generation in interrupt mode.
//	  * @param  htim TIM Base handle
//	  * @retval HAL status
//	  */
//	if (HAL_TIM_Base_Start_IT(&htim_cycle) != HAL_OK)
//	{
//		Error_Handler();
//	}
//}


//void ecss_tim_callback(TIM_HandleTypeDef *htim)
//{
////	FOCSS_ent status;
//	if(htim == &htim_cycle)
//	{
//		htim_cycle_flag++;
//	}
//}


//uint8_t	htim_cycle_flag_status()
//{
//	return htim_cycle_flag;
//}


//void htim_cycle_flag_decrease()
//{
//	if(htim_cycle_flag > 0)
//	{
//		htim_cycle_flag--;
//	}
//}


