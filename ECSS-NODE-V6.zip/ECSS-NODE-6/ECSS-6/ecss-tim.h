/*
 * ctrl-tim17.h
 *
 *  Created on: Mar 18, 2023
 *      Author: peterka
 */

#ifndef INC_ECSS_TIM_H_
#define INC_ECSS_TIM_H_

//#include "tim.h"

//#define htim_cycle (htim17)
//
//void tim17_init(void);
//uint8_t	htim_cycle_flag_status(void);
//void htim_cycle_flag_decrease(void);
//
//void ecss_tim_callback(TIM_HandleTypeDef *htim);

#endif /* INC_ECSS_TIM_H_ */
