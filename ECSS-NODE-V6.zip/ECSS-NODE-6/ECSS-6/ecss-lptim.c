/*
 * ctlr-lptim.c
 *
 *  Created on: Feb 2, 2023
 *      Author: peterka
 */

#include "ecss-lptim.h"

uint32_t	LPTIM1_count=0;

//	INTERRUPT	===========================================================

void LPTIM_init(void){ // init and use lpt<n> by interrupt
	if (HAL_LPTIM_Counter_Start_IT(&hlptim1, 0xffff) != HAL_OK)
	{
		Error_Handler();
	}
//	hlptim1.Instance->CNT = 0;
	__HAL_LPTIM_DISABLE_IT(&hlptim1, LPTIM_IT_ARROK);	// Disable autoreload write complete interrupt
//	HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFI);	// Enter in Stop mode
	__HAL_LPTIM_RESET_COUNTER_AFTERREAD(&hlptim1);
	HAL_LPTIM_ReadCounter(&hlptim1);	// set counter to zero, 0
}

void HAL_LPTIM_AutoReloadMatchCallback(LPTIM_HandleTypeDef *hlptim){ // Autoreload match after periode interrupt callback in non blocking mode
	if(hlptim == &hlptim1)
	{
		LPTIM1_count++;
		//HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
	}
}

uint32_t HAL_LPTIM_read(const LPTIM_HandleTypeDef *hlptim){
	uint32_t counth,countl,cpm,counttest;
	if(hlptim == &hlptim1)
	{
//		couter value is reset to 0 when reading
		countl = (uint32_t)HAL_LPTIM_ReadCounter(hlptim);
//		countl = hlptim->Instance->CNT;
//		hlptim->Instance->CNT = 0;
//		counttest = (uint32_t)HAL_LPTIM_ReadCounter(hlptim);
		if(LPTIM1_count > 65534){
			LPTIM1_count = 0;
			return 4294967295;
		}
		counth = LPTIM1_count;
		LPTIM1_count = 0;
		cpm = ((counth << 16) + countl);
		return cpm;
	}
	return 0;
}

//=========================================================================
