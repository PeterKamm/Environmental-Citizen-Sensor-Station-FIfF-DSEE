/*
 * ecss_periph.h
 *
 *  Created on: Jan 29, 2023
 *      Author: peterka
 */

#ifndef INC_ECSS_PERIPH_H_
#define INC_ECSS_PERIPH_H_

#include "main.h"
#include "ecss-lptim.h"
#include "ecss-tim.h"
#include "stm32g0xx_hal.h"
#include "i2c.h"
#include "bme68x.h"
#include "bme68x_defs.h"
#include "limits.h"
#include "dcf77.h"

//#define tim_gm (hlptim1)
//#define tim_bg51 (hlptim2)
//#define tim_cycle (htim17)
#define i2c_bme (hi2c1)

//	read all sensor values

void ecss_periph_init(void);
void ecss_periph_read_timestamp(void);
uint32_t ecss_periph_read_cpm(void);
int16_t ecss_periph_read_temperature(void);
void ecss_periph_read(void);

#endif /* INC_ECSS_PERIPH_H_ */
