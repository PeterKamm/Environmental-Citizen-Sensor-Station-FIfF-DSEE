/*
 * ecss_periph.c
 *
 *  Created on: Jan 29, 2023
 *      Author: peterka
 */


//	read all sensor values

#include "ecss_periph.h"
#include "FreeRTOS.h"
#include "task.h"

uint32_t cpm_bg51=0, temperature1=0;
uint64_t cpm_gm;

void bme_init(void);

void ecss_periph_init(void)
{
	LPTIM_init(); // init and use lpt<n> by interrupt
	dcf77_init();
	bme_init();

//	    if (rslt == BME680_OK)
//	    {
//	        printf("Chip ID 0x%x\n", bme680Dev.chip_id);
//	    }
}

//================ BME 680 =============================

struct bme68x_dev *bme;
struct bme68x_dev bme_struc;
uint8_t bme_dev_addr;
#define i2c_timeout (uint32_t)(1000)
#define data_len (uint16_t)(50)

//void bme_selftest(void)
//{
//	struct bme68x_dev bme;
//    int8_t rslt;
//
//    /* Interface preference is updated as a parameter
//     * For I2C : BME68X_I2C_INTF
//     * For SPI : BME68X_SPI_INTF
//     */
//    rslt = bme68x_interface_init(&bme, BME68X_I2C_INTF);
//    bme68x_check_rslt("bme68x_interface_init", rslt);
//
//    rslt = bme68x_init(&bme);
//    bme68x_check_rslt("bme68x_init", rslt);
//
//    rslt = bme68x_selftest_check(&bme);
//    bme68x_check_rslt("bme68x_selftest_check", rslt);
//
//    if (rslt == BME68X_OK)
//    {
//        printf("Self-test passed\n");
//    }
//
//    if (rslt == BME68X_E_SELF_TEST)
//    {
//        printf("Self-test failed\n");
//    }
//
//    bme68x_coines_deinit();
//
//    return rslt;
//
//}

uint8_t data_write[data_len];

BME68X_INTF_RET_TYPE bme68x_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr)
{
//    uint8_t dev_addr = *(uint8_t*)intf_ptr;
//    return coines_write_i2c(COINES_I2C_BUS_0, dev_addr, reg_addr, (uint8_t *)reg_data, (uint16_t)len);
//    HAL_StatusTypeDef HAL_I2C_Master_Transmit(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint8_t *pData, uint16_t Size, uint32_t Timeout)
	HAL_StatusTypeDef hal_ret;
    uint16_t i,n;
//    uint8_t data[data_len];
	if(len < data_len)
	{
		n = (uint16_t) len;
		data_write[0] = reg_addr;
		for(i=0; i<n; i++)
		{
			data_write[i+1]=reg_data[i];
		}
		hal_ret = HAL_I2C_Master_Transmit(&hi2c1, bme_dev_addr, data_write, i+1, i2c_timeout);
		return 0;
	}
    return 1;
}


uint8_t data_read[data_len];

BME68X_INTF_RET_TYPE bme68x_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr)
{
//    uint8_t dev_addr = *(uint8_t*)intf_ptr;
//    HAL_StatusTypeDef hal_ret;
//    return coines_read_i2c(i2c_bme, i2c_dev_addr, reg_addr, reg_data, (uint16_t)len);
	HAL_StatusTypeDef hal_ret;
//	uint8_t data[data_len];

    if(len < data_len)
    {
		data_read[0] = reg_addr;
		hal_ret = HAL_I2C_Master_Transmit(&hi2c1, bme_dev_addr, data_read, 1, i2c_timeout);
    	hal_ret = HAL_I2C_Master_Receive(&hi2c1, bme_dev_addr, reg_data, (uint16_t) len, i2c_timeout);
    	return 0;
    	}
    return 1;
}



void bme68x_delay_us(uint32_t period, void *intf_ptr)
{
	if (period < 2000){
		return;
//	}else if(period < 2000){
//		osDelay(2);
	}else{
//		HAL_Delay(period/(uint32_t)1000);
//		osDelay(period/(uint32_t)1000000);
		vTaskDelay(period/1000);
	}
}


struct bme68x_conf conf;
struct bme68x_heatr_conf heatr_conf;
struct bme68x_data newdata;


void bme_init(void)
{
//	int8_t bme_result;
	bme_dev_addr = (BME68X_I2C_ADDR_LOW << 1);
	bme = &bme_struc;
	bme->read = bme68x_i2c_read;
	bme->write = bme68x_i2c_write;
	bme->intf = BME68X_I2C_INTF;
	bme->delay_us = bme68x_delay_us;
	bme->intf_ptr = &bme_dev_addr;
	bme->amb_temp = 25; /* The ambient temperature in deg C is used for defining the heater temperature */
//	bme_result = bme68x_init(&bme_dev_addr);

//	struct bme68x_dev bme;
	int8_t rslt;
//	struct bme68x_conf conf;
//	struct bme68x_heatr_conf heatr_conf;
//	struct bme68x_data data;
//	uint32_t del_period;
//	uint32_t time_ms = 0;
//	uint8_t n_fields;
//	uint16_t sample_count = 1;


	rslt = bme68x_init(bme);
//	bme68x_check_rslt("bme68x_init", rslt);

	/* Check if rslt == BME68X_OK, report or handle if otherwise */
	conf.filter = BME68X_FILTER_OFF;
	conf.odr = BME68X_ODR_NONE;
	conf.os_hum = BME68X_OS_16X;
	conf.os_pres = BME68X_OS_1X;
	conf.os_temp = BME68X_OS_2X;
	rslt = bme68x_set_conf(&conf, bme);
//	bme68x_check_rslt("bme68x_set_conf", rslt);

	/* Check if rslt == BME68X_OK, report or handle if otherwise */
	heatr_conf.enable = BME68X_ENABLE;
	heatr_conf.heatr_temp = 300;
	heatr_conf.heatr_dur = 100;

	rslt = bme68x_set_heatr_conf(BME68X_FORCED_MODE, &heatr_conf, bme);

	//	int8_t bme68x_set_heatr_conf(uint8_t op_mode, const struct bme68x_heatr_conf *conf, struct bme68x_dev *dev)
//	bme68x_check_rslt("bme68x_set_heatr_conf", rslt);

}



//#include <stdio.h>
//#include "bme68x.h"
//#include "common.h"
//#include "coines.h"

/***********************************************************************/
/*                         Macros                                      */
/***********************************************************************/

/* Macro for count of samples to be displayed */
#define SAMPLE_COUNT  UINT16_C(300)

/***********************************************************************/
/*                         Test code                                   */
/***********************************************************************/

int bme_read(void)
{
//    struct bme68x_dev bme;
    int8_t rslt;
//    struct bme68x_conf conf;
//    struct bme68x_heatr_conf heatr_conf;
//    struct bme68x_data data;
    uint32_t del_period;
//    uint32_t time_ms = 0;
    uint8_t n_fields;
    uint16_t sample_count = 1;

    /* Interface preference is updated as a parameter
     * For I2C : BME68X_I2C_INTF
     * For SPI : BME68X_SPI_INTF
     */
//    rslt = bme68x_interface_init(&bme, BME68X_SPI_INTF);
//    bme68x_check_rslt("bme68x_interface_init", rslt);

//    rslt = bme68x_init(&bme);
//    bme68x_check_rslt("bme68x_init", rslt);

    /* Check if rslt == BME68X_OK, report or handle if otherwise */
//    conf.filter = BME68X_FILTER_OFF;
//    conf.odr = BME68X_ODR_NONE;
//    conf.os_hum = BME68X_OS_16X;
//    conf.os_pres = BME68X_OS_1X;
//    conf.os_temp = BME68X_OS_2X;
//    rslt = bme68x_set_conf(&conf, &bme);
//    bme68x_check_rslt("bme68x_set_conf", rslt);

    /* Check if rslt == BME68X_OK, report or handle if otherwise */
//    heatr_conf.enable = BME68X_ENABLE;
//    heatr_conf.heatr_temp = 300;
//    heatr_conf.heatr_dur = 100;
//    rslt = bme68x_set_heatr_conf(BME68X_FORCED_MODE, &heatr_conf, &bme);
//    bme68x_check_rslt("bme68x_set_heatr_conf", rslt);

//    printf("Sample, TimeStamp(ms), Temperature(deg C), Pressure(Pa), Humidity(%%), Gas resistance(ohm), Status\n");

    while (sample_count < SAMPLE_COUNT)
    {
        rslt = bme68x_set_op_mode(BME68X_FORCED_MODE, bme);
//        bme68x_check_rslt("bme68x_set_op_mode", rslt);

        /* Calculate delay period in microseconds */
        del_period = bme68x_get_meas_dur(BME68X_FORCED_MODE, &conf, bme) + (heatr_conf.heatr_dur * 1000);
        bme->delay_us(del_period, bme->intf_ptr);

//        time_ms = coines_get_millis();

        /* Check if rslt == BME68X_OK, report or handle if otherwise */
        rslt = bme68x_get_data(BME68X_FORCED_MODE, &newdata, &n_fields, bme);
//        bme68x_check_rslt("bme68x_get_data", rslt);

//        if (n_fields)
//        {
//#ifdef BME68X_USE_FPU
//            printf("%u, %lu, %.2f, %.2f, %.2f, %.2f, 0x%x\n",
//                   sample_count,
//                   (long unsigned int)time_ms,
//                   data.temperature,
//                   data.pressure,
//                   data.humidity,
//                   data.gas_resistance,
//                   data.status);
//#else
//            printf("%u, %lu, %d, %lu, %lu, %lu, 0x%x\n",
//                   sample_count,
//                   (long unsigned int)time_ms,
//                   (data.temperature / 100),
//                   (long unsigned int)data.pressure,
//                   (long unsigned int)(data.humidity / 1000),
//                   (long unsigned int)data.gas_resistance,
//                   data.status);
//#endif
            sample_count++;
//        }
//    }

//    bme68x_coines_deinit();
    }
    return rslt;
}




//============================================================================================================


void ecss_periph_read_timestamp(void){
}

uint32_t ecss_periph_read_cpm(void){
	// when reading, the counter value will be reset
	return HAL_LPTIM_read(&hlptim1);
}

int16_t ecss_periph_read_temperature(void){
	int16_t result;
	result=bme_read();
	return newdata.temperature;
}

//void ecss_periph_read(void){
//	ecss_periph_read_timestamp();
//	ecss_periph_read_cpm();
//	ecss_periph_read_temperature();
//}

