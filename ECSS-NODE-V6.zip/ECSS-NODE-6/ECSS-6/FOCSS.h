/*
 * FOCSS.h
 *
 *  Created on: 28.01.2023
 *      Author: peterka
 */

#ifndef INC_FOCSS_H_
#define INC_FOCSS_H_

//#include "stm32g0xx_hal.h"
#include "string.h"
#include "main.h"
#include "usart.h"

#define huart_lrw (huart2)
//#define huart_user
#define huart_user (huart3)

typedef enum
{
	FOCSS_false		= 0,
	FOCSS_HAL_OK	= HAL_OK,
	FOCSS_HAL_ERROR	= HAL_ERROR,
	FOCSS_HAL_BUSY	= HAL_BUSY,
	FOCSS_HAL_TIMEOUT	= HAL_TIMEOUT,
	FOCSS_OK		= 10,
	FOCSS_true,
	FOCSS_busy,
	FOCSS_get,		// DevEui AppEui DevAddr
	FOCSS_user,		// transmit data to user
	FOCSS_set,		// DevEui AppEui DevAddr
	FOCSS_set_key,	// APPKEY
	FOCSS_join,
	FOCSS_compare,
} FOCSS_ent;

#define lrw_buf_r_len 256

void FOCSS_init(void);
FOCSS_ent FOCSS_user_transmit(uint8_t *string);
FOCSS_ent FOCSS_lrw_tr(uint8_t *buf_t, uint16_t size_t, uint8_t *buf_r, uint16_t size_r);
FOCSS_ent FOCSS_lrw_cmd(FOCSS_ent cmd);
FOCSS_ent FOCSS_lrw_send_test2(void);
FOCSS_ent FOCSS_lrw_send(void);

#endif /* INC_FOCSS_H_ */
