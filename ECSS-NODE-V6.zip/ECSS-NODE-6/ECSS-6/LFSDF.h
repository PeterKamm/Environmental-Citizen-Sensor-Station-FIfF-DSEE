/*!
  * LFSDF.H
  */
#ifndef __LFSDF_H__
#define __LFSDF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

//	if defined, then output will be Strings, otherwise binary
//	except for function "writeByte(s)"

#define LFSDFtoString

void LFSDFInit(void);

typedef enum {simple, null, test} LFSDFResetEnum;
void LFSDFReset(LFSDFResetEnum cmd);

uint8_t LFSDFGetSize(void);

uint8_t *LFSDFGetBuffer(void);

void LFSDFWriteByte(uint8_t byte);

void LFSDFWriteBytes(uint8_t *bytes, uint16_t size);

void LFSDFWriteString(char *string);

void LFSDFTestOverwrite(void);

uint8_t LFSDFCopy(uint8_t *buffer);

uint8_t LFSDFWritePage(uint8_t page, char *str);

uint8_t LFSDFAddTimestamp(int32_t time, char *strp);

uint8_t LFSDFAddCPM(uint8_t channel, uint32_t cpm, char *str);

uint8_t LFSDFAddDigitalInput(uint8_t channel, uint8_t value, char *str);

uint8_t LFSDFAddDigitalOutput(uint8_t channel, uint8_t value, char *str);

uint8_t LFSDFAddAnalogInput( uint8_t channel, float value, char *str);

uint8_t LFSDFAddAnalogOutput( uint8_t channel, float value, char *str);

uint8_t LFSDFAddLuminosity(uint8_t channel, uint16_t lux, char *str);

uint8_t LFSDFAddPresence(uint8_t channel, uint8_t value, char *str);

uint8_t LFSDFAddTemperature( uint8_t channel, float celsius, char *str);

uint8_t LFSDFAddRelativeHumidity( uint8_t channel, float rh, char *str);

uint8_t LFSDFAddAccelerometer( uint8_t channel, float x, float y, float z, char *str);

uint8_t LFSDFAddBarometricPressure( uint8_t channel, float hpa, char *str);

uint8_t LFSDFAddGyrometer( uint8_t channel, float x, float y, float z, char *str);

uint8_t LFSDFAddGps( uint8_t channel, float latitude, float longitude, float meters, char *str);

//uint8_t LFSDFAdduSievert(uint8_t channel, uint32_t uSv);


/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

#ifdef __cplusplus
}
#endif

#endif /* __LFSDF_H__ */
