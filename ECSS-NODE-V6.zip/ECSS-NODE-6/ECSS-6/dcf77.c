/*
 * dcf77.c
 *
 *  Created on: May 7, 2023
 *      Author: peterka
 */

#include "dcf77.h"

#include "stm32g0xx_hal.h"
#include "FreeRTOS.h"
#include "stream_buffer.h"
#include "task.h"

#define dcf77_pin ((uint16_t)GPIO_PIN_12)
//#define dcf77_pin 100
//(0x0001)


uint32_t tstamp_rising, tstamp_falling;	// time stamp
StreamBufferHandle_t dcf77_sbh;
enum dcf77_polatity {init,pos,neg} dcf77ps;// polarity state dcf77
uint8_t dcf77bs;					// bit state processing the dcf77 bits


/*	0		init
	1..59	bit 1..59 recocnized
*/


void dcf77_init(void)
{
	dcf77_sbh = xStreamBufferCreate(10, 2);
	tstamp_rising = tstamp_falling = xTaskGetTickCount();
	dcf77ps = init;
	dcf77bs = init;
//	HAL_GPIO_EXTI_IRQHandler(dcf77_pin);
}


void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin)
//void HAL_GPIO_EXTI_Rising_Callback(dcf77_pin)
{
	size_t size;
	uint16_t tdiff;
	if(GPIO_Pin == dcf77_pin)
	{
		tstamp_rising = xTaskGetTickCountFromISR();
		tdiff = (uint16_t)(tstamp_rising - tstamp_falling);
		if(tdiff > 0x7FFF){
			tdiff = 0x7FFF;
		}
		tdiff = tdiff & 0x7FFF;				// set MSB = 0
		size = xStreamBufferSendFromISR(dcf77_sbh,&tdiff,sizeof(tdiff),NULL);
	}
}


void HAL_GPIO_EXTI_Falling_Callback(uint16_t GPIO_Pin)
{
	size_t size;
	uint16_t tdiff;
	if(GPIO_Pin == dcf77_pin)
	{
		tstamp_falling = xTaskGetTickCountFromISR();
		tdiff = (uint16_t)(tstamp_falling - tstamp_rising);
		if(tdiff > 0x7FFF){
			tdiff = 0x7FFF;
		}
		tdiff = tdiff | 0x8000;				// set MSB = 1
		size = xStreamBufferSendFromISR(dcf77_sbh,&tdiff,sizeof(tdiff),NULL);
	}
}


//	calculate signals of dcf77 timing values
#define	dcf77_zero_min	0x300
#define	dcf77_zero_max	0x380
#define	dcf77_one_min	0x730
#define	dcf77_one_max	0x790
#define	dcf77_short_min	0x300
#define	dcf77_short_max	0x380
#define	dcf77_long_min	0x730
#define	dcf77_long_max	0x790

#define smax 1000
uint16_t hist[smax];
uint16_t histv[smax];
uint16_t signal_init=0;
uint16_t maxh=0;

void dcf77_stat(void){	// dcf77 signal statistic
	uint16_t i,j;
	size_t size;
	uint16_t tdiff;
//	if(signal_init == 0){
//		for(i=0; i<smax; i++){
//			 hist[i]=0;
//			 histv[i]=0;
//		}
//		signal_init = 1;
//	}
	size = xStreamBufferReceive(dcf77_sbh,&tdiff,sizeof(tdiff),portMAX_DELAY);
//	if(tdiff==0){
//		hist[0]++;
//	} else {
//		for(i=1; i < smax; i++){
//			if(histv[i]==0){
//				hist[i]++;
//				histv[i]=tdiff;
//				maxh++;
//				break;
//			} else if(histv[i]==tdiff){
//				hist[i]++;
//				break;
//			} else if(tdiff < histv[i]){
//				for(j=maxh; j >= i; j--){
//					hist[j+1] = hist[j];
//					histv[j+1] = histv[j];
//				}
//				maxh++;
//				hist[i]=1;
//				histv[i] = tdiff;
//				break;
//			}
//		}
//	}
}


void dcf_stat_print(void){
	uint16_t i;
	for(i=0; i<smax; i++){
		if(hist[i] > 1){
//			printf("%6d : %6d \n\r", hist[i], histv[i]);
		}
	}
}


void dcf77_signal(void)
{
	size_t size;
	uint16_t tdiff;
	size = xStreamBufferReceive(dcf77_sbh,&tdiff,sizeof(tdiff),portMAX_DELAY);

	switch(dcf77ps)
	{
		case init :

		break;
		case pos :
		break;
		case neg :
		break;
		default :
		break;

		if(tdiff < 0x300){				// undefined
		} else if (tdiff < 0x380) {		// "0"
		} else if (tdiff < 0x730) {		// undefined
		} else if (tdiff < 0x790) {		// "1"
		} else if (tdiff < 0x8040) {	// normal pause between bits
		} else if (tdiff < 0x8100) {	// undefined
		} else if (tdiff < 0x8200) {	// long pause: start of sequence
		} else {						// undefined
		}
	}
//	if((tdiff > 0x8050) && (tdiff < 0x8080))
//	{
//	8067 805f 76e 311 386
//	{
//
//	}
}
