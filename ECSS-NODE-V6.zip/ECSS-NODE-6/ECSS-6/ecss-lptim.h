/*
 * ctlr-lptim.h
 *
 *  Created on: Feb 2, 2023
 *      Author: peterka
 */

#ifndef INC_ECSS_LPTIM_H_
#define INC_ECSS_LPTIM_H_

#include "stm32g0xx_hal.h"
#include "lptim.h"

void LPTIM_init(void); // init and use lpt<n> by interrupt
void HAL_LPTIM_AutoReloadMatchCallback(LPTIM_HandleTypeDef *hlptim); // Autoreload match after periode interrupt callback in non blocking mode
uint32_t HAL_LPTIM_read(const LPTIM_HandleTypeDef *hlptim);

#endif /* INC_ECSS_LPTIM_H_ */
